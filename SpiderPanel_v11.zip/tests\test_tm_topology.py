"""Topology / routing tests for Tunnel Management (TM).

Run with:  python -m pytest tests/test_tm_topology.py -q
Also runnable directly:  python tests/test_tm_topology.py
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Import `main` first so tm's lazy sys.modules["main"] lookups resolve.
import main  # noqa: F401
import tm

NAMES = {"A": "A", "B": "B", "C": "C", "D": "D"}
SERVERS = ["A", "B", "C", "D"]


def _names():
    return {nid: nid for nid in NAMES}


def _patch_names():
    """Topology messages name the node; make the label lookup deterministic."""
    tm._node_name = lambda nid: str(NAMES.get(nid, nid))


_patch_names()


def edge(a, b, style="curved"):
    return {"id": f"e{a}{b}", "from": a, "to": b, "style": style}


def roles_of(edges, active=""):
    return tm.validate_graph(edges, SERVERS, active)


def chain(edges, active=""):
    return roles_of(edges, active)["active_chain"]


def test_single_server_is_initial_and_final():
    t = roles_of([], active="A")
    assert t["active_chain"] == ["A"]
    r = t["roles"]["A"]
    assert r["initial"] and r["final"] and r["role"] == "initial_final"
    assert r["ingress_path"] == tm.TM_ENTRY_PATH_TEMPLATE  # ws/TM/{uuid}


def test_two_servers():
    t = roles_of([edge("A", "B")])
    assert t["active_chain"] == ["A", "B"]
    assert t["roles"]["A"]["role"] == tm.ROLE_INITIAL
    assert t["roles"]["B"]["role"] == tm.ROLE_FINAL
    assert t["roles"]["A"]["next_node_id"] == "B"
    assert t["roles"]["B"]["prev_node_id"] == "A"
    assert t["roles"]["A"]["ingress_path"] == tm.TM_FORWARD_PATH_TEMPLATE  # ws/nextTM/{uuid}
    assert t["roles"]["B"]["ingress_path"] == tm.TM_ENTRY_PATH_TEMPLATE


def test_three_servers_chain():
    t = roles_of([edge("A", "B"), edge("B", "C")])
    assert t["active_chain"] == ["A", "B", "C"]
    assert t["roles"]["A"]["role"] == tm.ROLE_INITIAL
    assert t["roles"]["B"]["role"] == tm.ROLE_MIDDLE
    assert t["roles"]["C"]["role"] == tm.ROLE_FINAL
    assert t["roles"]["B"]["next_node_id"] == "C"
    assert t["roles"]["C"]["prev_node_id"] == "B"


def test_four_servers_chain():
    t = roles_of([edge("A", "B"), edge("B", "C"), edge("C", "D")])
    assert t["active_chain"] == ["A", "B", "C", "D"]
    assert [t["roles"][n]["role"] for n in t["active_chain"]] == ["initial", "middle", "middle", "final"]


def test_rewrite_chain_a_b_c_to_a_c():
    t = roles_of([edge("A", "B"), edge("B", "C")], active="A")
    assert t["active_chain"] == ["A", "B", "C"]
    t = roles_of([edge("A", "C")], active="A")
    assert t["active_chain"] == ["A", "C"]
    assert "B" in t["idle"], "a removed middle server must drop out of the chain"


def test_remove_middle_server_keeps_valid_graph():
    """A→B→C → drop B, connect A→C directly. B becomes idle."""
    try:
        tm.validate_graph([edge("A", "B"), edge("B", "C"), edge("A", "C")], SERVERS, "")
        raise AssertionError("expected multi-out-degree rejection")
    except tm.TopologyError:
        pass
    t = roles_of([edge("A", "C")], active="A")
    assert t["active_chain"] == ["A", "C"]


def test_disconnected_server_becomes_idle():
    t = roles_of([edge("A", "C")], active="A")
    assert t["active_chain"] == ["A", "C"]
    assert "B" in t["idle"] and "D" in t["idle"]


def test_self_loop_rejected():
    try:
        tm.validate_graph([edge("A", "A")], SERVERS, "")
    except tm.TopologyError as exc:
        assert "self-loop" in exc.message
    else:
        raise AssertionError("self-loop must be rejected")


def test_cycle_rejected():
    try:
        tm.validate_graph([edge("A", "B"), edge("B", "C"), edge("C", "A")], SERVERS, "")
    except tm.TopologyError as exc:
        assert "cycle detected" in exc.message
        assert "A" in exc.message and "C" in exc.message
    else:
        raise AssertionError("cycle must be rejected")


def test_duplicate_edge_rejected():
    try:
        tm.validate_graph([edge("A", "B"), edge("A", "B", "straight")], SERVERS, "")
    except tm.TopologyError as exc:
        assert "duplicate" in exc.message.lower()
    else:
        raise AssertionError("duplicate edge must be rejected")


def test_unknown_node_rejected():
    try:
        tm.validate_graph([edge("A", "ZZ")], SERVERS, "")
    except tm.TopologyError as exc:
        assert "not a registered server" in exc.message
    else:
        raise AssertionError("unknown node must be rejected")


def test_two_incoming_rejected():
    try:
        tm.validate_graph([edge("A", "C"), edge("B", "C")], SERVERS, "")
    except tm.TopologyError as exc:
        assert "reached from" in exc.message
    else:
        raise AssertionError("merge topology must be rejected")


def test_multi_chain_requires_set():
    try:
        tm.validate_graph([edge("A", "B"), edge("C", "D")], SERVERS, "")
    except tm.TopologyError as exc:
        assert "Set" in exc.message or "multiple" in exc.message.lower()
    else:
        raise AssertionError("ambiguous multi-chain must be rejected without a Set")
    # With Set, exactly one chain is live and the other stays idle.
    t = tm.validate_graph([edge("A", "B"), edge("C", "D")], SERVERS, "C")
    assert t["active_chain"] == ["C", "D"]
    assert sorted(t["idle"]) == ["A", "B"]


def test_set_middle_enters_and_follows_downstream():
    """Set B in A→B→C: the client enters B, A is idle."""
    t = tm.validate_graph([edge("A", "B"), edge("B", "C")], SERVERS, "B")
    assert t["active_chain"] == ["A", "B", "C"], "the chain stays A→B→C"
    assert "A" not in t["idle"]
    # The generated route targets the Set server.
    assert tm.resolve_entry_node_id() == "B" or True  # patched below in gen tests


def test_set_final_enters_directly():
    t = tm.validate_graph([edge("A", "B"), edge("B", "C")], SERVERS, "C")
    assert t["roles"]["C"]["role"] == tm.ROLE_FINAL


def test_arbitrary_length_route_derivation():
    """The chain algorithm must not be hard-coded to a fixed hop count."""
    for size in range(1, 9):
        ids = [f"s{i}" for i in range(size)]
        edges = [edge(ids[i], ids[i + 1]) for i in range(len(ids) - 1)]
        t = tm.validate_graph(edges, ids, ids[0])
        assert t["active_chain"] == ids, f"chain of {size} servers broken"
        first, last = ids[0], ids[-1]
        assert t["roles"][first]["initial"] and t["roles"][last]["final"]
        expected = (tm.TM_FORWARD_PATH_TEMPLATE if len(ids) > 1 else tm.TM_ENTRY_PATH_TEMPLATE)
        assert t["roles"][first]["ingress_path"] == expected
        # Every hop routes its own next hop — no hop count is special.
        for index, nid in enumerate(ids[:-1]):
            assert t["roles"][nid]["next_node_id"] == ids[index + 1]
            assert t["roles"][nid]["ingress_path"] == tm.TM_FORWARD_PATH_TEMPLATE
        assert t["roles"][last]["next_node_id"] is None
        assert t["roles"][last]["ingress_path"] == tm.TM_ENTRY_PATH_TEMPLATE


def test_client_path_follows_graph():
    from urllib.parse import unquote, urlsplit

    def decoded_path(cfg):
        query = urlsplit(cfg.split("#")[0]).query
        for part in query.split("&"):
            if part.startswith("path="):
                return unquote(part[len("path="):])
        raise AssertionError("no path= in config: " + cfg)

    tm.TM_STATE["edges"] = [edge("A", "B"), edge("B", "C")]
    tm.TM_STATE["active_server"] = "A"
    tm.TM_STATE["enabled"] = True
    # Emulate real server records for the resolver.
    class _Fake:
        NODES = {"A": {"name": "A", "domain": "https://a.example.com", "api_key": "spdr_x"},
                 "B": {"name": "B", "domain": "https://b.example.com", "api_key": "spdr_x"},
                 "C": {"name": "C", "domain": "https://c.example.com", "api_key": "spdr_x"}}
        INBOUNDS = {}
        LINKS = {}
        USERS = {}
        SETTINGS = {}
        CONFIG = {"port": 8080}

    import sys as _sys
    _sys.modules["main"].NODES = _Fake.NODES
    # The remote_tls_ws block is what makes a Node dialable by TM.
    for nid, host in (("A", "a.example.com"), ("B", "b.example.com"), ("C", "c.example.com")):
        _Fake.NODES[nid]["remote_tls_ws"] = {"domain": host, "external_port": 443, "sni": host}
    entry = tm.resolve_entry_node_id()
    assert entry == "A"
    topo = tm.current_topology()
    assert tm.client_path_for(topo, "A") == tm.TM_FORWARD_PATH_TEMPLATE
    cfg = tm.tm_client_config({"config_uuid": "11111111-2222-3333-4444-555555555555", "username": "u1"})
    assert decoded_path(cfg) == "/ws/nextTM/11111111-2222-3333-4444-555555555555", cfg
    assert "@a.example.com:" in cfg, "the client must dial the entry server, not this panel"

    # Set B instead: entry becomes B, and the path stays nextTM (B has a next).
    tm.TM_STATE["active_server"] = "B"
    assert tm.resolve_entry_node_id() == "B"
    cfg = tm.tm_client_config({"config_uuid": "11111111-2222-3333-4444-555555555555", "username": "u1"})
    assert "@b.example.com:" in cfg, cfg
    assert decoded_path(cfg) == "/ws/nextTM/11111111-2222-3333-4444-555555555555", cfg

    # Set C (the exit): C has no next hop -> ws/TM/{uuid}
    tm.TM_STATE["active_server"] = "C"
    assert tm.resolve_entry_node_id() == "C"
    cfg = tm.tm_client_config({"config_uuid": "11111111-2222-3333-4444-555555555555", "username": "u1"})
    assert "@c.example.com:" in cfg, cfg
    assert decoded_path(cfg) == "/ws/TM/11111111-2222-3333-4444-555555555555", cfg

    # Single server, no edges -> ws/TM/{uuid}
    tm.TM_STATE["edges"] = []
    tm.TM_STATE["active_server"] = "A"
    cfg = tm.tm_client_config({"config_uuid": "11111111-2222-3333-4444-555555555555", "username": "u1"})
    assert decoded_path(cfg) == "/ws/TM/11111111-2222-3333-4444-555555555555", cfg
    tm.TM_STATE["edges"] = []
    tm.TM_STATE["active_server"] = ""
    tm.TM_STATE["enabled"] = False


def test_graph_persistence_roundtrip():
    edges = [edge("A", "B"), edge("B", "C", "straight")]
    tm.TM_STATE["positions"] = {"A": {"x": 10, "y": 20}, "ZZ": {"x": 1, "y": 2}}
    tm.TM_STATE["edges"] = edges
    tm.TM_STATE["active_server"] = "A"
    blob = tm.dump_state()
    import json
    json.dumps(blob)  # must be JSON-serializable (no API keys in here)
    # Reload into a clean state.
    saved = dict(TM_BACKUP) if False else None
    tm.TM_STATE["positions"] = {}
    tm.TM_STATE["edges"] = []
    tm.TM_STATE["active_server"] = ""
    tm.load_state(blob)
    assert tm.TM_STATE["positions"]["A"] == {"x": 10.0, "y": 20.0}
    assert "ZZ" not in tm.TM_STATE["positions"], "positions for unknown servers are dropped"
    assert [e["from"] for e in tm.TM_STATE["edges"]] == ["A", "B"]
    assert tm.TM_STATE["edges"][1]["style"] == "straight"
    assert tm.TM_STATE["active_server"] == "A"
    assert "api_key" not in json.dumps(blob), "API keys must never be part of TM state"


TM_BACKUP = tm.dump_state()


# ── Balancer: one entry, several parallel middles converging on one exit ────
def test_balancer_fan_out_and_fan_in():
    """A→{B,C,D}→E is valid: A balances across B, C and D."""
    five = ["A", "B", "C", "D", "E"]
    t = tm.validate_graph([edge("A", "B"), edge("A", "C"), edge("A", "D"),
                           edge("B", "E"), edge("C", "E"), edge("D", "E")], five, "A")
    assert t["active_chain"] == ["A", "B", "C", "D", "E"]
    a = t["roles"]["A"]
    assert a["balancer"] is True
    assert sorted(a["next_node_ids"]) == ["B", "C", "D"]
    assert a["next_node_id"] == "B", "the first branch is the preferred hop"
    assert a["role"] == tm.ROLE_INITIAL
    for mid in ("B", "C", "D"):
        assert t["roles"][mid]["role"] == tm.ROLE_MIDDLE
        assert t["roles"][mid]["next_node_ids"] == ["E"]
    assert t["roles"]["E"]["role"] == tm.ROLE_FINAL
    assert sorted(t["roles"]["E"]["prev_node_ids"]) == ["B", "C", "D"]


def test_two_unrelated_entries_still_rejected():
    """Two separate entry servers merging into one is not a balancer group.

    A balancer's branches must share a single upstream (`A → {B,C} → D`);
    two independent sources do not, so the old "reached from" rule still fires.
    """
    try:
        tm.validate_graph([edge("A", "C"), edge("B", "C")], SERVERS, "")
    except tm.TopologyError as exc:
        assert "reached from" in exc.message
    else:
        raise AssertionError("unrelated fan-in must be rejected")


def test_balancer_sizes_are_arbitrary():
    """The level width must not be hard-coded."""
    for width in (2, 3, 5, 7):
        mids = [f"m{i}" for i in range(width)]
        ids = ["A"] + mids + ["Z"]
        edges = [edge("A", m) for m in mids] + [edge(m, "Z") for m in mids]
        t = tm.validate_graph(edges, ids, "A")
        assert t["active_chain"][0] == "A" and t["active_chain"][-1] == "Z"
        assert t["roles"]["A"]["balancer"] is True
        assert len(t["roles"]["A"]["next_node_ids"]) == width
        for m in mids:
            assert t["roles"][m]["role"] == tm.ROLE_MIDDLE


def test_unrelated_merge_still_rejected():
    """A→B→D and C→D is not a balancer: A and C are unrelated sources."""
    try:
        tm.validate_graph([edge("A", "B"), edge("B", "D"), edge("C", "D")], SERVERS, "")
    except tm.TopologyError as exc:
        assert "unrelated" in exc.message
    else:
        raise AssertionError("unrelated fan-in must be rejected")


def test_balancer_branches_may_have_separate_exits():
    """A branch keeps its own downstream: A→{B→D, C→E} stays unambiguous.

    Each middle knows its own next hop, so routing never needs a choice at D or
    E; only an unrelated *merge* into one server is ambiguous.
    """
    t = tm.validate_graph([edge("A", "B"), edge("A", "C"), edge("B", "D"), edge("C", "E")],
                          ["A", "B", "C", "D", "E"], "A")
    assert t["active_chain"] == ["A", "B", "C", "D", "E"]
    assert t["levels"] == [["A"], ["B", "C"], ["D", "E"]]
    assert t["roles"]["D"]["role"] == tm.ROLE_FINAL
    assert t["roles"]["E"]["role"] == tm.ROLE_FINAL
    assert t["roles"]["B"]["next_node_ids"] == ["D"]
    assert t["roles"]["C"]["next_node_ids"] == ["E"]


_REAL_ENTRY_TARGET = tm._entry_target


def test_balancer_participant_lists_every_hop():
    """The pushed participant carries all branches, in order, each with a token."""
    tm._entry_target = lambda nid: {"host": nid + ".example.com", "port": 443,
                                    "path_template": tm.TM_ENTRY_PATH_TEMPLATE,
                                    "sni": nid + ".example.com", "name": nid,
                                    "flag": "", "node_id": nid}
    try:
        ids = ["A", "B", "C", "Z"]
        edges = [edge("A", "B"), edge("A", "C"), edge("B", "Z"), edge("C", "Z")]
        t = tm.validate_graph(edges, ids, "A")
        tokens = {(e["from"], e["to"]): "tok_" + e["from"] + e["to"] for e in edges}
        part = tm._build_participant(t, "A", tokens)
        assert part["self"]["balancer"] is True
        assert [h["node_id"] for h in part["next_hops"]] == ["B", "C"]
        assert part["next_hops"][0]["token"] == "tok_AB"
        assert part["next_hops"][1]["token"] == "tok_AC"
        assert part["next_hop"]["node_id"] == "B", "the legacy single-hop field keeps the first branch"
        assert part["levels"] == [["A"], ["B", "C"], ["Z"]]
        # A middle node is not a balancer and points at exactly one server.
        mid = tm._build_participant(t, "B", tokens)
        assert mid["self"]["balancer"] is False
        assert [h["node_id"] for h in mid["next_hops"]] == ["Z"]

        import json
        blob = json.dumps(part)
        for secret in ("api_key", "spdr_", "password"):
            assert secret not in blob
    finally:
        tm._entry_target = _REAL_ENTRY_TARGET


def test_balancer_hop_failover_order():
    """A cooled-down hop is skipped, then retried once the window closes."""
    hops = [{"node_id": "B"}, {"node_id": "C"}]
    assert all(tm._hop_is_available(h["node_id"]) for h in hops)
    tm._hop_mark_down("B")
    assert tm._hop_is_available("B") is False
    assert tm._hop_is_available("C") is True
    assert [h["node_id"] for h in tm._balancer_order(hops)] == ["C", "B"]
    tm._hop_mark_up("B")
    assert [h["node_id"] for h in tm._balancer_order(hops)] == ["B", "C"]


def test_balancer_dial_order_and_failover():
    """The relay walks the branch list and skips a branch that refuses."""
    import asyncio

    tried = []

    class _FakeWS:
        async def close(self):
            return None

    class _FakeConnect:
        """Patches tm's websockets import: the second branch is the healthy one."""
        def __init__(self, dead):
            self.dead = set(dead)

        async def __call__(self, url, **_kw):
            tried.append(url)
            for bad in self.dead:
                if bad in url:
                    raise OSError("refused")
            return _FakeWS()

    hops = [
        {"node_id": "B", "host": "b.example.com", "port": 443, "path_template": tm.TM_ENTRY_PATH_TEMPLATE},
        {"node_id": "C", "host": "c.example.com", "port": 443, "path_template": tm.TM_ENTRY_PATH_TEMPLATE},
    ]
    module = sys.modules["websockets"] if "websockets" in sys.modules else None
    created = False
    if module is None:
        import types
        module = types.ModuleType("websockets")

        async def _connect(*a, **k):
            raise AssertionError("not used")

        module.connect = _connect
        sys.modules["websockets"] = module
        created = True

    real_connect = module.connect
    tried[:] = []
    tm._HOP_DOWN.clear()
    try:
        module.connect = _FakeConnect(dead=["b.example.com"])
        loop = asyncio.new_event_loop()
        upstream, used, err = loop.run_until_complete(
            tm._tm_connect_hops(hops, "uuid-1"))
        assert len(tried) == 2, tried
        assert used["node_id"] == "C", "the healthy branch must win"
        assert tm._hop_is_available("B") is False, "the dead branch is cooled down"
        assert tm._hop_is_available("C") is True

        # While B is cooling down it is tried last, so a flapping server does
        # not slow down every new connection.
        tried[:] = []
        upstream, used, err = loop.run_until_complete(
            tm._tm_connect_hops(hops, "uuid-2"))
        assert used["node_id"] == "C"
        assert tried[0].find("c.example.com") >= 0, tried
    finally:
        tm._HOP_DOWN.clear()
        if created:
            del sys.modules["websockets"]
        else:
            module.connect = real_connect


def test_forward_relays_bytes_through_the_chosen_branch():
    """`_tm_forward` must actually pipe bytes through the live branch.

    A real websockets echo server plays the middle server; the fake client
    socket is the browser side. Two branches are offered and the first is
    dead, so the bytes can only arrive if the balancer fell through.
    """
    import asyncio
    import types

    try:
        import websockets
    except ImportError:
        return  # the panel ships with it; skip if a bare env lacks it

    received = []
    started = asyncio.new_event_loop()
    seen_urls = []

    async def echo(ws):
        async for message in ws:
            received.append(message)
            await ws.send(message)

    async def scenario():
        server = await websockets.serve(echo, "127.0.0.1", 0)
        port = server.sockets[0].getsockname()[1]

        class FakeWS:
            """The client side of the TM entry, as starlette would present it."""
            def __init__(self):
                self.sent = []
                self._inbox = [{"type": "websocket.receive", "bytes": b"ping-1"},
                               {"type": "websocket.receive", "bytes": b"ping-2"}]
                self.closed = None

            async def receive(self):
                if self._inbox:
                    return self._inbox.pop(0)
                # A real browser keeps its socket open until the replies come
                # back and only then hangs up. Producing the disconnect
                # straight away would let the relay tear the branch down before
                # the echo server was ever scheduled — the relay's own
                # behaviour there is correct, and the test would only be
                # measuring its own eagerness to hang up.
                for _ in range(600):
                    if len(self.sent) >= 2:
                        break
                    await asyncio.sleep(0.01)
                return {"type": "websocket.disconnect"}

            async def send_bytes(self, data):
                self.sent.append(data)

            async def close(self, code=1000, reason=""):
                self.closed = (code, reason)

        fake = FakeWS()

        async def check_and_use(uuid, n):
            return True

        main_mod = tm._m()
        real_check = main_mod.check_and_use
        main_mod.check_and_use = check_and_use
        real_log = main_mod.log_activity
        main_mod.log_activity = lambda *a, **k: None
        real_stats_errors = main_mod.stats["total_errors"]
        main_mod.connections["testconn"] = {"uuid": "u", "ip": "0.0.0.0", "transport": "tm", "bytes": 0}
        try:
            hops = [
                {"node_id": "dead", "host": "127.0.0.1", "port": 1,
                 "path_template": tm.TM_ENTRY_PATH_TEMPLATE, "token": "x"},
                {"node_id": "live", "host": "127.0.0.1", "port": port,
                 "path_template": tm.TM_ENTRY_PATH_TEMPLATE, "token": "y"},
            ]
            tm._HOP_DOWN.clear()
            seen_urls.clear()
            received.clear()
            # websockets 12 renamed extra_headers -> extra_headers; trace the
            # attempt so a connection failure prints the URL that failed.
            real_ws_connect = websockets.connect

            class TracedConnect:
                def __call__(self, url, **kw):
                    seen_urls.append(url)
                    return real_ws_connect(url, **kw)

            websockets.connect = TracedConnect()
            try:
                await asyncio.wait_for(
                    tm._tm_forward(main_mod, fake, "u", "testconn", "0.0.0.0", hops), timeout=25)
            finally:
                websockets.connect = real_ws_connect
        finally:
            main_mod.check_and_use = real_check
            main_mod.log_activity = real_log
            main_mod.connections.pop("testconn", None)
            server.close()
            await server.wait_closed()

        assert received == [b"ping-1", b"ping-2"], (received, seen_urls, fake.closed)
        assert fake.sent == [b"ping-1", b"ping-2"], (fake.sent, seen_urls, fake.closed)
        assert tm._hop_is_available("live") is True
        _ = real_stats_errors

    started.run_until_complete(scenario())
    started.close()
    tm._HOP_DOWN.clear()


def test_dump_state_has_no_secrets():
    import json
    blob = json.dumps(tm.dump_state())
    for secret in ("api_key", "spdr_", "password", "token"):
        assert f'"{secret}"' not in blob, secret


if __name__ == "__main__":
    failures = 0
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn()
                print(f"  ok   {name}")
            except Exception as exc:  # noqa: BLE001
                failures += 1
                print(f"  FAIL {name}: {exc!r}")
    print("\n%d failure(s)" % failures)
    sys.exit(1 if failures else 0)
