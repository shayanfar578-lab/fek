"""Static syntax checks for the TM additions in static/index.html.

Writes the extracted <script> payload to a temp file and parses it with the
`esprima` script via a JS-less trick is not possible, so this uses a tiny
brace/paren/bracket balance + function-name sanity scan instead. Real DOM
verification is done in preview mode.
"""
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
html = (ROOT / "static" / "index.html").read_text(encoding="utf-8", errors="replace")

failures = []


def check(name, cond, detail=""):
    print(("  ok   " if cond else "  FAIL ") + name + ((" — " + detail) if detail and not cond else ""))
    if not cond:
        failures.append(name)


# 1. The script tag must contain the whole TM module.
for fn in ("loadTM", "tmSetSection", "tmRenderServers", "tmRenderGraph", "tmRenderEdges",
           "tmRenderNodes", "tmPointerDown", "tmPointerMove", "tmPointerUp", "tmActivateDrag",
           "tmPingNode", "tmPingAllMissing", "tmSetServer",
           "tmGenerate", "tmPickLink", "tmRetarget", "tmValidateEdges", "tmPingEdge",
           "tmAutoStyle", "tmFit", "tmZoomButton", "tmApplyTransform",
           "tmOpenServerModal", "tmSubmitServer", "tmDeleteServer", "tmPersistPositionsSoon",
           "tmMeasureOnce", "tmRemoteOrigin",
           "tmEdgeGeometry", "tmBoxExit", "tmSaveGraph", "tmDropMissingRefs",
           "tmRenderEdgeChip", "tmAddEdge", "tmPathExists",
           "tmCancelConnect", "tmDeleteEdge", "tmToggleNode", "tmPingThis",
           "tmUpdatePingUI", "tmRenderStatus", "tmMeasureNodes", "tmNodeBox",
           "tmBindCanvas", "tmCanvasPoint", "tmWheel", "tmCancelPress",
           "tmCopyConfig", "tmServerById", "tmEdgeById", "tmEdgeFor", "tmRoleOf",
           # automatic apply (no Apply button any more) and the timed chips
           "tmSetAutoState", "tmScheduleApply", "tmAutoApply", "tmClearEdgePings",
           "tmRenderProgress", "tmArmChipTimer", "tmArmNodeTimer",
           # magnetic, draggable bars
           "tmSnapNodeAt", "tmShowSnap", "tmClearSnap", "tmActivateBar", "tmCancelBar",
           "tmBarMove", "tmBarDrop", "tmEdgeBend", "tmRenderEdgesSoon",
           # the two ping kinds shown separately
           "tmPingServerHealth", "tmPingServer", "tmClientPingText", "tmClientPingDown"):
    check("script has " + fn, ("function " + fn + "(") in html)

# 2. Every onclick/data-i18n function referenced in the TM HTML must exist.
handlers = set(re.findall(r'onclick="(tm[A-Za-z]+)\(', html))
for h in sorted(handlers):
    check("onclick " + h, ("function " + h + "(") in html)

# 2b. Every tm.* key used by the UI must be defined, in BOTH languages.
fa_start = html.index("Object.assign(I18N.fa")
en_start = html.index("Object.assign(I18N.en", fa_start)
en_end = html.index("Object.assign(I18N.fa", en_start)
fa_block = html[fa_start:en_start]
en_block = html[en_start:en_end]
used_keys = set(re.findall(r"data-i18n=\"(tm\.[A-Za-z_.]+)\"", html))
used_keys |= set(re.findall(r"\bt\('(tm\.[A-Za-z_.]+)'", html))
# A key built by concatenation (`'tm.role.' + role`) is a PREFIX, not a key: it
# is checked as a family instead, and must not enter the missing-key list.
dyn_prefix = {k for k in used_keys if k.endswith('.')}
used_keys -= dyn_prefix
dyn_prefix |= set(re.findall(r"t\('(tm\.[A-Za-z_]+\.)'\s*\+", html))
fa_keys = set(re.findall(r"'(tm\.[A-Za-z_.]+)':", fa_block))
en_keys = set(re.findall(r"'(tm\.[A-Za-z_.]+)':", en_block))
check("every tm.* key used by the UI is defined", not (used_keys - fa_keys - en_keys),
      "missing: " + ", ".join(sorted(used_keys - fa_keys - en_keys)))
for prefix in sorted(dyn_prefix):
    ok = any(k.startswith(prefix) for k in fa_keys) and any(k.startswith(prefix) for k in en_keys)
    check("dynamic key family " + prefix + "*", ok)
check("fa and en define the same tm.* keys", fa_keys == en_keys,
      "fa-only: %s | en-only: %s" % (sorted(fa_keys - en_keys), sorted(en_keys - fa_keys)))

# 3. No API key handling leaks into the TM JS section: only masked placeholders
#    and the localStorage-free rule — TM must never READ the stored full key.
tm_block = html[html.index("TUNNEL MANAGEMENT (TM)"):]
tm_js = tm_block[:tm_block.index("</script>")]
check("TM JS never reads a stored API key",
      "_fullApiKey" not in tm_js and "panel-api-key" not in tm_js and "localStorage.getItem('spider" not in tm_js.replace("localStorage.getItem('spider-theme'", "").replace("localStorage.getItem('spider-lang'", ""),
      "a full-key read found in TM JS")
check("only masked spdr_ placeholder occurrences", html.count("spdr_xxxxxxxxx") == 4,
      "count=%d" % html.count("spdr_xxxxxxxxx"))

# 4. Structural HTML: parse the document and require the TM tab + its panels.
from html.parser import HTMLParser


class Tree(HTMLParser):
    VOID = {"br", "img", "input", "meta", "link", "hr", "source", "col"}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.stack = []
        self.by_id = {}
        self.errors = []

    def handle_starttag(self, tag, attrs):
        d = dict(attrs)
        if "id" in d:
            self.by_id[d["id"]] = tag
        if tag not in self.VOID:
            self.stack.append(tag)

    def handle_endtag(self, tag):
        if tag in self.VOID:
            return
        if tag in self.stack:
            while self.stack and self.stack[-1] != tag:
                self.errors.append("unclosed <%s> before </%s>" % (self.stack[-1], tag))
                self.stack.pop()
            if self.stack:
                self.stack.pop()
        else:
            self.errors.append("stray </%s>" % tag)


tree = Tree()
tree.feed(html)
check("html parser reports no mismatched tags", not tree.errors,
      "; ".join(tree.errors[:4]))

for required in ("tab-tm", "tm-canvas", "tm-node-layer", "tm-edge-layer", "tm-server-list",
                 "tm-subnav", "tm-section-server", "tm-section-configure", "tm-zoom",
                 "tm-progress", "tm-config-preview", "mod-tm-server", "nav-tm",
                 "tm-statusbar", "tm-mode-label", "tm-srv-name",
                 "tm-srv-domain", "tm-srv-key", "tm-server-modal-title",
                 # the auto-apply badge replaces the removed Apply button
                 "tm-auto-state"):
    check("element #" + required, required in tree.by_id)

# The server accordion (and its client/server ping rows) is built by JS.
check("servers render as an accordion", 'class="spd-acc tm-server-acc"' in html)
check("server accordion shows both ping kinds",
      "tm-lat-tag-client" in html and "tm-lat-tag-server" in html)
# The TM tab must sit inside the Management accordion in the sidebar.
nav_pos = html.find('id="nav-tm"')
acc_body = html.find('id="main-nav-accordion-body"')
check("TM tab is inside the Management accordion",
      acc_body >= 0 and nav_pos > acc_body,
      "nav-tm=%d accordion-body=%d" % (nav_pos, acc_body))

print("\n%d failure(s)" % len(failures))
sys.exit(1 if failures else 0)
