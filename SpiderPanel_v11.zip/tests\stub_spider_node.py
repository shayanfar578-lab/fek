"""A minimal stand-in for a remote SpiderPanel, used by the TM API tests.

Serves just enough of the real surface for the panel's Node probe and for TM's
peer/RPC endpoints:

    GET  /api/server-info      -> probe payload (default_tls_ws, public_ip, …)
    POST /api/tm/peer/config   -> records the pushed participant config
    GET  /api/tm/peer/status   -> what a participant would report
    POST /api/tm/peer/hop-ping -> {"ok": true, "ms": <configured>}
    GET  /api/tm/peer/ping     -> {"ok": true, "service": "spider-tm"}
    POST /__ctl                -> {"fail_peer": bool} to force a failing push

Run:  python tests/stub_spider_node.py <port> <name> [hop_ms]
"""
from __future__ import annotations

import json
import socket
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 18081
NAME = sys.argv[2] if len(sys.argv) > 2 else "stub"
HOP_MS = int(sys.argv[3]) if len(sys.argv) > 3 else 42

# `hops` is filled by the panel when it pushes this node's participant config,
# so hop-ping tests the same target the real relay would dial.
STATE = {"fail_peer": False, "pushed": [], "status": "online", "hops": []}


class Handler(BaseHTTPRequestHandler):
    def _send(self, code: int, payload: dict) -> None:
        raw = json.dumps(payload).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(raw)

    def _body(self) -> dict:
        length = int(self.headers.get("Content-Length") or 0)
        if not length:
            return {}
        try:
            return json.loads(self.rfile.read(length).decode())
        except Exception:
            return {}

    def do_GET(self):  # noqa: N802
        path = self.path.split("?")[0]
        if path == "/api/server-info":
            self._send(200, {
                "public_ip": "203.0.113.%d" % (PORT % 250),
                "host": "127.0.0.1:%d" % PORT,
                "domain": "127.0.0.1:%d" % PORT,
                "country": "Stubland",
                "country_code": "ST",
                "country_flag": "🏳",
                "users": 0,
                "default_tls_ws": {
                    "id": "dw",
                    "network": "ws",
                    "security": "tls",
                    "domain": "127.0.0.1",
                    "external_port": PORT,
                    "sni": "127.0.0.1",
                    "path": "/ws/{uuid}",
                },
            })
            return
        if path == "/api/tm/peer/ping":
            self._send(200, {"ok": True, "t": 0, "service": "spider-tm"})
            return
        if path == "/api/tm/peer/status":
            self._send(200, {"ok": True, "status": {"participant": STATE["pushed"][-1] if STATE["pushed"] else None}})
            return
        self._send(404, {"ok": False, "error": "not found"})

    def do_POST(self):  # noqa: N802
        path = self.path.split("?")[0]
        body = self._body()
        if path == "/__ctl":
            STATE.update(body)
            self._send(200, {"ok": True, "state": STATE})
            return
        if path == "/api/tm/peer/config":
            if STATE["fail_peer"]:
                self._send(500, {"ok": False, "error": "forced failure"})
                return
            STATE["pushed"].append(body)
            # Remember the dial targets this node is supposed to use, exactly
            # like the real panel stores its own next hops.
            hops = body.get("next_hops") or []
            if not hops and body.get("next_hop"):
                hops = [body["next_hop"]]
            STATE["hops"] = hops
            self._send(200, {"ok": True})
            return
        if path == "/api/tm/peer/chain-ping":
            # Walk the remaining path exactly like a real participant: one real
            # TCP connect per hop, starting from this stub. Anything unreachable
            # makes the whole walk fail rather than reporting a partial number.
            rest = [h for h in (body.get("path") or []) if isinstance(h, dict)]
            total, count = 0, 0
            for hop in rest:
                host = str(hop.get("host") or "")
                port = int(hop.get("port") or 443)
                started = time.perf_counter()
                try:
                    with socket.create_connection((host, port), timeout=3.0):
                        pass
                except Exception as exc:
                    self._send(200, {"ok": False, "ms": None, "hops": count,
                                     "error": str(exc)[:120]})
                    return
                total += max(1, round((time.perf_counter() - started) * 1000))
                count += 1
            self._send(200, {"ok": True, "ms": total, "hops": count, "error": ""})
            return
        if path == "/api/tm/peer/hop-ping":
            # Measure the hop the panel asks about for real: connect to its
            # host:port and report the round trip. A refused connection must
            # come back as no measurement, never as a fake 42 ms.
            wanted = str(body.get("to") or "")
            target = None
            for hop in (STATE["hops"] or []):
                if not wanted or str(hop.get("node_id")) == wanted:
                    target = hop
                    break
            if not target or not target.get("host"):
                self._send(200, {"ok": True, "ms": None, "error": "no next hop configured"})
                return
            host = str(target["host"])
            port = int(target.get("port") or 443)
            started = time.perf_counter()
            try:
                with socket.create_connection((host, port), timeout=3.0):
                    pass
            except Exception as exc:
                self._send(200, {"ok": True, "ms": None, "error": str(exc)[:120]})
                return
            self._send(200, {"ok": True, "ms": max(1, round((time.perf_counter() - started) * 1000))})
            return
        self._send(404, {"ok": False, "error": "not found"})

    def log_message(self, *_args):  # silence access log
        pass


if __name__ == "__main__":
    server = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    print("stub node %s on 127.0.0.1:%d" % (NAME, PORT), flush=True)
    try:
        threading.Event().wait()
    except KeyboardInterrupt:
        pass
