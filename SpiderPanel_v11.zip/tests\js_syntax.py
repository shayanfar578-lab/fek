"""Parse the panel's inline <script> with esprima; report the first syntax error."""
import re
import sys
from pathlib import Path

import esprima

ROOT = Path(__file__).resolve().parent.parent
html = (ROOT / "static" / "index.html").read_text(encoding="utf-8", errors="replace")

scripts = re.findall(r"<script(?![^>]*\bsrc=)[^>]*>(.*?)</script>", html, re.S | re.I)
print(f"{len(scripts)} inline script block(s)")
failed = 0
for i, src in enumerate(scripts):
    try:
        esprima.parseScript(src, {"loc": True, "tolerant": False, "jsx": False})
        print(f"  ok   script[{i}] ({len(src)} chars)")
    except Exception as exc:
        failed += 1
        line = getattr(getattr(exc, "lineNumber", None), "__int__", lambda: 0)()
        print(f"  FAIL script[{i}] ({len(src)} chars): {exc}")
        if line:
            for n in range(max(1, line - 4), line + 2):
                print(f"        {n}: {src.splitlines()[n - 1][:160]}")
sys.exit(1 if failed else 0)
